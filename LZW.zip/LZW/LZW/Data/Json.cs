﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LZW.Data
{
    public class Json
    {
        public string nombreArchivo { get; set; }
        public string ubicacionComprimido { get; set; }
        public double razonCompresion { get; set; }
        public double factorCompresion  { get; set; }
        public double porcentajeCompresion { get; set; }

    }
}
