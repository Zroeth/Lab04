﻿using System;
using System.IO;



namespace Prueba
{
    class Program
    {
        static void Main(string[] args)
        {
           Console.Write("Escribir texto: ");
            string texto = Console.ReadLine();



           

            using (StreamWriter outputFile = new StreamWriter("Prueba.txt"))
            {
                    outputFile.WriteLine(texto);
            }


            Console.Write("Huffman");
            Operaciones impHuffman = new Operaciones("Prueba.txt", "Arbol");

            impHuffman.Comprimir();
            impHuffman.Descomporimir();


            Console.Write("LZW");
            Operaciones impLZW = new Operaciones("Prueba.txt", "Arbol");

            impLZW.Comprimir();
            impLZW.Descomporimir();

        }
    }
}
